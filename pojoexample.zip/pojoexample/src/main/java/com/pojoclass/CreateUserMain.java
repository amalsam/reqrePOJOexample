package com.pojoclass;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;;

public class CreateUserMain {
	CreateUserPOJO reqPayload = new CreateUserPOJO();
	
	public void createUser() {
		RestAssured.baseURI = "https://reqres.in";
		RestAssured.useRelaxedHTTPSValidation();
		reqPayload.setName("amal");
		reqPayload.setJob("tester");
		
		CreateuserResponsePOJO objRes = given()
		.contentType(ContentType.JSON)
		.body(reqPayload)
		.when()
		.post("/api/users")
		.then().log().all()
		.assertThat().statusCode(201)
		.extract().response().as(CreateuserResponsePOJO.class);
		
		System.out.println(objRes.getId());
		System.out.println(objRes.getName());
		System.out.println(objRes.getJob());
		System.out.println(objRes.getcreatedAt());
		
		
	}

}
