package com.ust.pojoexample;

import org.testng.annotations.Test;

import com.pojoclass.CreateUserMain;

public class NewTest {
  @Test
  public void test() {
	  new CreateUserMain().createUser();
  }
}
